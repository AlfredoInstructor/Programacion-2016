create table administrador(
Usuario varchar(20) not null primary key,
Contraseña varchar(30) not null,
NombreAdmin varchar(50) not null
);

create table votacion(
IDVotacion int auto_increment not null primary key,
Nombre varchar(30) not null,
Detalles varchar(200),
Tiempo time,
Fecha date not null,
Usuario varchar(20) not null,
constraint fk_admin foreign key (Usuario) references Administrador(Usuario)
);

create table candidato(
CICandidato int(8) not null primary key,
Nombre varchar(30) not null,
Apellido varchar(30) not null,
Foto text,
Descripcion varchar(100)

);

create table votante(
CIVotante int(8) not null primary key,
IDVotacion int not null,
constraint fk_votacionV foreign key (IDVotacion) references votacion(IDVotacion)
);

create table postulo(
IDVotacion int,
CICandidato int(8),
Cantidadvotos int,
primary key(IDVotacion, CICandidato),
constraint fk_votacionPo foreign key (IDVotacion) references votacion(IDVotacion),
constraint fk_candidatoPo foreign key (CICandidato) references candidato(CICandidato)
);